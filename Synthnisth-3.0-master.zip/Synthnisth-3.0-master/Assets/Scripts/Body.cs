﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Body : MonoBehaviour {

	public CharacterBehaviours character;//passar o character como parametro no inspector
    public float timeToDeath; //vai indicar o tempo até ativar o game over
    public float counter; //é um cronômetro
    public bool dieing = false; //fica verdadeira quando o player encosta na plataforma insta kill

    private void Update()
    {
        counter += Time.deltaTime; //incrementa o cronômetro conforme o tempo vai passando
        if (counter > timeToDeath && dieing) //se o cronometro passar do timeToDeath e já tiver encostado na plataforma insta kill
            character.GameOver(); //chame a função GameOver
    }

    void OnTriggerEnter2D(Collider2D other){
        if (other.gameObject.tag == "PowerBox")
        {//esse bloco destroy o powerblock e pega o poder contido nela
            Destroy(other.gameObject);
            PowerBlock _power = other.gameObject.GetComponent<PowerBlock>();
            character.PowerUp(_power.power);
        }
        else if (other.gameObject.tag == "Insta Kill")
        { //esse bloco recarrega a fase caso o protagonista encoste em algum objeto que o mate instantaneamente
            character.an.SetBool("Dead", true);
            counter = 0f; // zera o cronômetro
            timeToDeath = 0.45f; //define o tempo até o game over
            dieing = true; //ativa o booleano, indicando que o player encostou na plataforma insta kill
        }
	}
}
