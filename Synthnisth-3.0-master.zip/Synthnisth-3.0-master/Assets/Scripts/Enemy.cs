﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

    public bool faceRight;
    public SpriteRenderer sprEnemy;
    public float speed;
    private Rigidbody2D rgbEnemy;
    private Transform playerPos;
    public bool playerView, attackZone;
    public bool inAttack;
    public bool dieing = false;
    public float radiusSight;
    public float radiusAttack;
    public float radiusSightIncrease;
    public float radiusSightDecrease;
    public LayerMask playerLayer;
    public Sword sword;
    public Animator an;
    public float counter;
    public float timeToAttack = 1.25f;
    public BoxCollider2D shock;
    

    // Use this for initialization
    void Start() {
        speed = 3f;
        rgbEnemy = GetComponent<Rigidbody2D>();
        sprEnemy = GetComponent<SpriteRenderer>();
        playerPos = GameObject.Find("Character").GetComponent<Transform>();
        radiusSightIncrease = radiusSight * 1.5f;
        radiusSightDecrease = radiusSight;
        shock = gameObject.transform.GetChild(0).GetComponent<BoxCollider2D>();
    }

    void FixedUpdate()
    {
        playerView = Physics2D.OverlapCircle(this.transform.position, radiusSight, playerLayer);
        attackZone = Physics2D.OverlapCircle(this.transform.position, radiusAttack, playerLayer);
    }

    // Update is called once per frame
    void Update()
    {
        counter += Time.deltaTime;

        if (playerView)
        {
            an.SetBool("wake", true);
            Move(speed);
            radiusSight = radiusSightIncrease;
        }
        else
        {
            StopMoving();
            an.SetBool("wake", false);
            radiusSight = radiusSightDecrease;
        }

        Flip();

        if (attackZone)
        {
            if (!inAttack)
            {
                Attack();
                inAttack = true;
                counter = 0f;
            }
        }

        if (inAttack || dieing)
            StopMoving();

        if (counter >= timeToAttack && inAttack)
        {
            an.SetBool("attack", false);
            inAttack = false;
        }
    }

    public void Flip()
    {
        if (faceRight)
        {
            transform.eulerAngles = new Vector2(0, 0);
        }
        else
        {
            transform.eulerAngles = new Vector2(0, 180);
        }

        if (playerPos.position.x < transform.position.x)
        {
            faceRight = false;
        }
        else if (playerPos.position.x > transform.position.x)
        {
            faceRight = true;
        }
    }

    public void Move(float speeds)
    {
        float speedMovement = speeds;
        if (!faceRight)
        {
            speedMovement = -1 * speeds;
        }
        rgbEnemy.velocity = new Vector2(speedMovement, rgbEnemy.velocity.y);
        an.SetBool("run", true);
    }

    public void StopMoving()
    {
        rgbEnemy.velocity = Vector2.zero;
        an.SetBool("run", false);
    }

    public void Attack()
    {
        an.SetBool("attack", true);
    }

    public void ShockOn()
    {
        shock.gameObject.SetActive(true);
    }

    public void ShockOff()
    {
        shock.gameObject.SetActive(false);
    }

    public void Die()
    {
        Destroy(this.gameObject);
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Sword") && sword.striking == true)
        {
            an.SetBool("dead", true);
            dieing = true; 
        }
    }

    void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(this.transform.position, radiusSight);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(this.transform.position, radiusAttack);
    }
}
